import {
  Text,
  View
} from "react-native";
import React from "react";

const RegisterScreen = () => {
  return (
    
        <View >
          <Text >
            pls use google sign-in...
          </Text>
        </View>

  );
};

export default RegisterScreen;
