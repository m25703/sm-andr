import React, {useState, useEffect} from 'react';
import {View, Text, StyleSheet, FlatList, Image} from 'react-native';

const ComplaintsScreen = () => {
  return (
    <View>
      <Text>what is this for...</Text>
    </View>
  );
};

export default ComplaintsScreen;
